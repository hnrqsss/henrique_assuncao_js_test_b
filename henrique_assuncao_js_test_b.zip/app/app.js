window.onload = () => {
    
    const router = new Router()

    Backbone.history.start()
    
} 

